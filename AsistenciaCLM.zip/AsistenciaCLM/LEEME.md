# Asistencia CLM — app Android para pasar lista

App para controlar la asistencia del alumnado: faltas, retrasos, justificaciones,
corrección y borrado de anotaciones, informes por trimestre y calendario escolar
de Castilla-La Mancha 2026-2027 (Albacete, Ciudad Real, Cuenca, Guadalajara y Toledo)
con festivos locales configurables e importación de calendarios en PDF.

Funciona sin conexión. Los datos se guardan en el propio móvil; usa
*Grupos → Copia de seguridad* para exportarlos.

## Obtener el APK

### Opción A — Android Studio (recomendada)
1. Instala Android Studio (gratuito): https://developer.android.com/studio
2. *File → Open* y elige esta carpeta `AsistenciaCLM`. Espera a que termine la sincronización de Gradle.
3. *Build → Build App Bundle(s) / APK(s) → Build APK(s)*.
4. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.
   Pásalo al móvil e instálalo (Android pedirá permitir “instalar apps de origen desconocido”).
   También puedes conectar el móvil por USB y pulsar ▶ Run.

### Opción B — GitHub, sin instalar nada
1. Crea un repositorio en GitHub y sube el contenido de esta carpeta.
2. En la pestaña *Actions* se ejecuta “Compilar APK” automáticamente.
3. Al terminar, descarga el artefacto **Asistencia-APK** (contiene `app-debug.apk`).

## Estructura
- `app/src/main/assets/www/index.html` — toda la aplicación (interfaz y lógica).
- `app/src/main/assets/www/pdfjs/` — lector de PDF (pdf.js, licencia Apache 2.0), incluido para funcionar sin internet.
- `app/src/main/java/.../MainActivity.java` — contenedor Android (WebView, selector de archivos, exportar/compartir, botón atrás).

Para publicar en Google Play habría que firmar una versión *release* (Build → Generate Signed Bundle).
